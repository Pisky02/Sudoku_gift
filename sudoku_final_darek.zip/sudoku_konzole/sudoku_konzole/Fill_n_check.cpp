#include "Header.h"


void fill_block_with_0(int block[3][3]) {

	for (int row = 0; row < 3; row++) {
		for (int column = 0; column < 3; column++) {
			block[row][column] = 0;
		}
	}

}

void fill_board_with_0(int board[9][9]) {
	for (int row = 0; row < 9; row++) {
		for (int column = 0; column < 9; column++) {
			board[row][column] = 0;
		}
	}

}

void remove_solve_input(int board[9][9], int tried[9][9]) {
	for (int row = 0; row < 9; row++) {
		for (int col = 0; col < 9; col++) {
			if (tried[row][col] == 1) {
				board[row][col] = 0;
			}
		}
	}
}


int is_valid(int input, int row, int column, int board[9][9]) {

	// check row and col
	for (int i = 0; i < 9; i++) {		//i == row, j == column
		if (board[i][column] == input && i != row) return false;
		if (board[row][i] == input && i != column) return false;
	}

	//check block
	for (int row_block = 0; row_block < 3; row_block++) {
		for (int column_block = 0; column_block < 3; column_block++) {
			if (board[row_block + (3 * (row / 3))][column_block + (3 * (column / 3))] == input) return false;
		}
	}

	return true;
}

int  is_filled(int board[9][9]) {

	for (int row = 0; row < 9; row++) {
		for (int column = 0; column < 9; column++) {
			if (board[row][column] == 0) return 0;
		}
	}
	return 1;
}

int  block_isnot_filled(int block[3][3]) {

	int empty = 0;

	for (int row = 0; row < 3; row++) {
		for (int column = 0; column < 3; column++) {
			if (block[row][column] == 0) empty++;
		}
	}
	return empty;
}


void auto_delete_guess_numbers(int user_input, int usIn_row, int usIn_col, int number_stats[9], int game_board[9][9], int guess_board[9][9]) {

	//delete  all guesses and wrong answers when all of numbers are in board
	if (number_stats[user_input - 1] == 9) {
		for (int row = 0; row < 9; row++) {
			for (int col = 0; col < 9; col++) {
				if (guess_board[row][col] == user_input || guess_board[row][col] == - user_input) {
					guess_board[row][col] = 0;
				}
			}
		}
	}

	int block;
	int row_index, column_index;

	if (usIn_row < 3) {
		if (usIn_col < 3) block = 0;
		if (usIn_col > 2 && usIn_col < 6) block = 1;
		if (usIn_col > 5) block = 2;
	}
	if (usIn_row > 2 && usIn_row < 6) {
		if (usIn_col < 3) block = 3;
		if (usIn_col > 2 && usIn_col < 6) block = 4;
		if (usIn_col > 5) block = 5;
	}
	if (usIn_row > 5) {
		if (usIn_col < 3) block = 6;
		if (usIn_col > 2 && usIn_col < 6) block = 7;
		if (usIn_col > 5) block = 8;
	}

	switch (block) {
	case 0:
		row_index = 0, column_index = 0;
		break;
	case 1:
		row_index = 0, column_index = 1;
		break;
	case 2:
		row_index = 0, column_index = 2;
		break;
	case 3:
		row_index = 1, column_index = 0;
		break;
	case 4:
		row_index = 1, column_index = 1;
		break;
	case 5:
		row_index = 1, column_index = 2;
		break;
	case 6:
		row_index = 2, column_index = 0;
		break;
	case 7:
		row_index = 2, column_index = 1;
		break;
	case 8:
		row_index = 2, column_index = 2;
		break;
	}

	for (int row = 0; row < 3; row++) {
		for (int column = 0; column < 3; column++) {
			if (guess_board[row + 3 * row_index][column + 3 * column_index] == user_input 
				|| guess_board[row + 3 * row_index][column + 3 * column_index] == - user_input) {

				guess_board[row + 3 * row_index][column + 3 * column_index] = 0;
			}
		}
	}

}


int  sudoku_is_completed(int board[9][9]) {

	for (int row = 0; row < 9; row++) {
		for (int column = 0; column < 9; column++) {
			if (board[row][column] == 0) return false;
		}
	}
	return true;
}
