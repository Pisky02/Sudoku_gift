#pragma once

/****************************************************
*													*
*													*
*		  Tohle je proste jen mega cool...  		*
*													*
*													*
*****************************************************/

#include <conio.h>
//#include <dirent.h>
#include <errno.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
//#include <unistd.h>
#include <Windows.h>

#define ARROW_UP 72
#define ARROW_DOWN 80
#define ARROW_LEFT 75
#define ARROW_RIGHT 77
#define KB_ESC 27
#define KB_ENTER 13

#define COLOR_BOLD  "\033[30;48;5;11m"					// black with intense yellow bg
#define COLOR_CROSS  "\033[30;48;5;14m"					// black with intense light-blue bg
#define COLOR_CROSS_WRONG  "\033[1;31;48;5;14m"			// bright red with intense light-blue bg
#define COLOR_CROSS_GUESS  "\033[32;48;5;14m"			// green with intense light-blue bg
#define COLOR_GUESS_SELECTED  "\033[32;48;5;11m"		// green with intense yellow bg
#define COLOR_GUESS  "\033[1;32m"						// breight green
#define COLOR_WRONG_SELECTED  "\033[1;31;48;5;11m"		// breight red with intense yellow bg
#define COLOR_WRONG  "\033[1;31m"						// bright red
#define COLOR_OFF   "\033[m"							// end color

#define SUMOF_BLANK 50
#define BOARD_CONST 0.81								// sum of sudoku elements devided by 100 (for computing score)

//generate copletly filled sudoku grid
int  generate_sudoku(int board[9][9], int row, int col);	
//set number of blank elements
int  set_difficulty();			
//generates sudoku puzzle with unique solution
int  generate_game_board(int game_board[9][9], int sudoku_board[9][9], int nuber_stats[9]);	
//blank spots input
int fill_blank(int board[9][9], int sudoku[9][9], int blank_spots[9][9], int blank_tried[9][9], int miss, int difficulty, int* frow, int* fcol);
//check if there is only one solution
int solve_sudoku_stop_2(int board[9][9], int tried[9][9], int row, int col, int* solutions, int frow, int fcol);



//game
int  print_board(int board[9][9], int sudoku[9][9], int guess[9][9], int number_stats[9], int max_mistakes);
//if user fill number, same value guess numbers in a block are deleted
void auto_delete_guess_numbers(int user_input, int usIn_row, int usIn_col, int nuber_stats[9], int game_board[9][9], int guess_board[9][9]);
//check if board is full
int  sudoku_is_completed(int board[9][9]);



void fill_block_with_0(int block[3][3]);
void fill_board_with_0(int board[9][9]);
void remove_solve_input(int board[9][9], int tried[9][9]);

int is_valid(int input, int row, int column, int board[9][9]);
int  is_filled(int board[9][9]);
int  block_isnot_filled(int block[3][3]);

void save_score(int score);
void add_user_file(int sum_of_played_games, int score);
void add_new_user(char* file_name, int sum_of_played_games, int score);
void board2file(int board[9][9]);


void show_bt(int board[9][9]);
