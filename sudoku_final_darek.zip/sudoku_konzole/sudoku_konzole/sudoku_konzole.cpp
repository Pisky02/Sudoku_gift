﻿#include "Header.h"

/*
sudoku:
	9) umela inteligence ... nalezeni reseni
	11) moznost napovedy
	12) backtracking
		
		bt_board:
		* postupne vola bt_block pro vsechny blocky v boardu
			bt_block:
			* vygeneruje cislo v danem blocku


	13) moznost automatickeho doplneni, pokud zbyva jen poslednich par prazdnych poli
*/

int main()
{

	for (int test = 0; test < 36; test++) {

		int number_stats[9]{ 0 };

		int guess_board[9][9]{ 0 };
		int sudoku_board[9][9]{ 0 };

		int row = 0, col = 0;
		if (!generate_sudoku(sudoku_board, row, col)) {
			printf("Nepodarilo se vygenrerovat sudoku...");
		}

		int game_board[9][9]{ 0 };
		int element_score = generate_game_board(game_board, sudoku_board, number_stats);

		show_bt(game_board);

		board2file(game_board);
	}


	/*
	int max_mistakes = 0;
	int kb_input = 0;

	while (kb_input != 27) {

		int number_stats[9]{ 0 };

		int guess_board[9][9]{ 0 };
		int sudoku_board[9][9]{ 0 };

		int row = 0, col = 0;
		if (!generate_sudoku(sudoku_board, row, col)) {
			printf("Nepodarilo se vygenrerovat sudoku...");
		}

		int game_board[9][9]{ 0 };
		int element_score = generate_game_board(game_board, sudoku_board, number_stats);




		printf("Zadej max. pocet chyb: ");
		scanf_s("%d", &max_mistakes);

		int score = print_board(game_board, sudoku_board, guess_board, number_stats, max_mistakes);

		if (score >= 0) {
			system("cls");
			printf("Zvladl jsi to! Gratulujeme...\n\n");
		}
		else if (score == -1) {
			system("cls");
			printf("Bohuzel... tentokrat to nevyslo.\n\n");
		}

		Sleep(1000);

		kb_input = 0;
		while (kb_input != 13) {

			system("cls");

			printf("Pro ulozeni vasich statistyk stisknete Ctr + s...\n\n\n\n\n");

			printf("Pro zacatek nove hry stisknete Enter...\n");
			printf("Pro ukonceni hry stisknete ESC...");


			kb_input = _getch();
			if (kb_input == 19) save_score(score);
			if (kb_input == 27) break;
		}


	}*/



	return 0;
}

