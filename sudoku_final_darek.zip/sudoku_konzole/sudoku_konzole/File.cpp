#include "Header.h"

/******************************************
* FILE:
*	>> every user have unique file
*	1) User name
*	2) All saved games
*	4) Score (points for right inputs - points for wrong inputs)
*		>> one element score = pocet ztracenych poli / BOARD_CONST
*		>> ((adding score: old score * sum of all old gmames) + new score) / new sum of all games
* 
* 
*******************************************/

void board2file(int board[9][9]) {

	FILE* sud;
	fopen_s(&sud, "sudoku_board.txt", "r+");
	if (sud == NULL) {
		perror("Sudoku to file");
		return;
	}
	fseek(sud, 0, SEEK_END);
	for (int row = 0; row < 9; row++) {
		for (int col = 0; col < 9; col++) {
			if (board[row][col] == 0) {
				fprintf_s(sud, "\t");
			}
			else if(col == 8){
				fprintf_s(sud, "%d", board[row][col]);
			}
			else {
				fprintf_s(sud, "%d\t", board[row][col]);
			}
		}
		fprintf_s(sud, "\n");
	}
	fprintf_s(sud, "\n");
	fclose(sud);
}

void save_score(int score) {
	int kb_input = 0;
	int row = 0;

	while (kb_input != 13) {		//enter
		int point[3]{ 0 };
		point[row] = 'o';

		system("cls");

		printf("Pro ulzeni vaseho skore se musite prihlasit na svuj profil: \n\n");
		printf("Prihlaseni	%c", point[0]);
		printf("Registrace	%c", point[1]);

		kb_input = _getch();

		switch (kb_input) {
		case 72:

			break;
		case 77:

			break;
		}
	}


}

int select_player() {
	//nacte jmena vsech hracu
	//klasicky vyber pomoci matice
	return 0;
}

void add_user_file(int sum_of_played_games, int score) {

	/******************************************
	* 
	* search for files with name(user % d, user)
	* if pointer to file == NULL >> file does not exist
	* program creates new file 
	* than calls func to fill in user stats
	* 
	*******************************************/
	
	char file_name[255];
	int user = 0;

	FILE* us;

	while (1) {

		sprintf_s(file_name, "user%d.txt", user);
		fopen_s(&us, file_name, "r");
		if (us == NULL) {
			fopen_s(&us, file_name, "w");
			if (us == NULL) {
				perror("File");
				Sleep(300);
				return;
			}
			add_new_user(file_name, sum_of_played_games, score);
			return;
		}
		fclose(us);
		user++;
	}
}

void add_new_user(char* file_name, int sum_of_all_games, int score) {

	FILE* us;
	fopen_s(&us, file_name, "w");
	if (us == NULL) {
		perror("User data to file");
		return;
	}
	
	char user_name[100];
	system("cls");
	printf("Zadej sve jmeno: ");
	scanf_s("%s", user_name, (unsigned int)sizeof(user_name));
	fprintf(us, "%s\n", user_name);
	fprintf(us, "%d\n", sum_of_all_games);
	fprintf(us, "%d", score);
}
