#include "Header.h"



int generate_sudoku(int board[9][9], int row, int col) {

	int number_place;
	int generated_numbers[9]{ 0 };

	if (row == 9) return true;
	else if (col == 9) return generate_sudoku(board, row + 1, 0);
	else if (board[row][col] != 0) return generate_sudoku(board, row, col + 1);
	else {

		if (row == 0) {		//naplni prvni radek nahodne cisly 1 - 9

			for (int place = 9; place > 0; place--) {

				int number = 0;
				srand(time(NULL));
				number_place = rand() % place;		// 0 - (8, 7, 6 ...)

				for (int search_numb_arr = 0; search_numb_arr < 9; search_numb_arr++) {

					if (generated_numbers[search_numb_arr] == 1) {
						number++;
						continue;
					}

					if (number_place == 0) {
						board[row][col] = number + 1;
						//show_bt(board);	//ukazuje prubeh backtrackingu
						break;
					}

					number++;
					number_place--;					
				}
				generated_numbers[number] = 1;
				col++;

			}
			row = 1, col = 0;
		}
		for (int number = 1; number < 10; number++) {
			
			if (is_valid(number, row, col, board)) {
				board[row][col] = number;
				//show_bt(board);		//ukazuje prubeh backtrackingu
				if (generate_sudoku(board, row, col + 1)) return true;
				board[row][col] = 0;
			}
		}
		return false;
	}

	system("pause");
}

int  set_difficulty() {

	int kb_input = 0;
	int selected_row = 0;

	while (kb_input != 13) {

		char point[7]{ 0 };
		point[selected_row] = 'o';

		system("cls");
		printf("Vyber si obtiznost: \n\n");

		printf("Downuv syndrom		%c\n", point[0]);
		printf("Volic SPD		%c\n", point[1]);
		printf("Mel jsem uz 5 piv	%c\n", point[2]);
		printf("Mid			%c\n", point[3]);
		printf("Fourierova rada		%c\n", point[4]);
		printf("Kdo byl v Parizi?	%c\n", point[5]);
		printf("Udelej si sam		%c\n", point[6]);


		kb_input = _getch();

		switch (kb_input) {
		case ARROW_UP:	//up
			if (selected_row > 0) {
				selected_row--;
			}
			break;
		case ARROW_DOWN:	//down
			if (selected_row < 6) {
				selected_row++;
			}
			break;
		}
	}


	switch (selected_row) {
	case 0:
		return 20;
	case 1:
		return 40;
	case 2:
		return 45;
	case 3:
		return 50;
	case 4:
		return 55;
	case 5:
		return 58;
	case 6:

		while (1) {
			int chosen_difficulty;
			system("cls");
			printf("Zadej mnozstvi prazdnych poli (max. 58): ");
			scanf_s("%d", &chosen_difficulty);
			if (chosen_difficulty <= 58) return chosen_difficulty;
		}

	}

	return 0;
}

int generate_game_board(int game_board[9][9], int sudoku_board[9][9], int number_stats[9]) {


	int difficulty = set_difficulty();
	int element_score = difficulty / BOARD_CONST;
	int blank_spots[9][9]{ 0 };


	int tried[9][9]{ 0 };
	int frow = 0, fcol = 0;

	int result = fill_blank(game_board, sudoku_board, blank_spots, tried, 0, difficulty, &frow, &fcol);

	if (result != 1) {
		printf("Error\n");
		Sleep(1000);
		exit(0);
	}

	for (int row = 0; row < 9; row++) {
		for (int column = 0; column < 9; column++) {
			if (blank_spots[row][column] == 0) {
				number_stats[sudoku_board[row][column] - 1]++;
			}
		}
	}

	return element_score;
}

int fill_blank(int board[9][9], int sudoku[9][9], int blank_spots[9][9], int blank_tried[9][9], int miss, int difficulty, int* frow, int* fcol) {


	if (miss == difficulty) return 1;
	else if (is_filled(blank_tried)) {
		printf("XXX\n");
		system("pause");
		fill_board_with_0(blank_spots);
		fill_board_with_0(blank_tried);
		*frow = 0, * fcol = 0;

		return fill_blank(board, sudoku, blank_spots, blank_tried, 0, difficulty, frow, fcol);
	}
	else {

		printf("%d\n", miss);

		srand(time(NULL));

		int tried[9][9]{ 0 };
		int row, col;

		do {
			row = rand() % 9;
			col = rand() % 9;
		} while (blank_spots[row][col] == 1 || blank_tried[row][col] == 1);

		blank_spots[row][col] = 1;
		blank_tried[row][col] = 1;

		if (miss == 0) {
			*frow = row;
			*fcol = col;	// souradnice prvniho prazdneho bodu
		}

		else if (row < *frow) {
			*frow = row;
			*fcol = col;
		}

		else if (row == *frow && col < *fcol) {
			*fcol = col;
		}

		fill_board_with_0(board);
		fill_board_with_0(tried);



		for (int i_row = 0; i_row < 9; i_row++) {
			for (int j_column = 0; j_column < 9; j_column++) {
				if (blank_spots[i_row][j_column] == 0) {
					board[i_row][j_column] = sudoku[i_row][j_column];
				}
			}
		}
		
		int solutions = 0;
		int result = solve_sudoku_stop_2(board, tried, *frow, *fcol, &solutions, *frow, *fcol);

		switch (result) {
		case 0:
			exit(0);
		case 1:
			return fill_blank(board, sudoku, blank_spots, blank_tried, miss + 1, difficulty, frow, fcol);
		case -1:
			blank_spots[row][col] = 0;
			return fill_blank(board, sudoku, blank_spots, blank_tried, miss, difficulty, frow, fcol);
		}
	}

}

int solve_sudoku_stop_2(int board[9][9], int tried[9][9], int row, int col, int* solutions, int frow, int fcol) {

	if (row == 9) {
		if (*solutions == 0) {
			*solutions = *solutions + 1;
			return 0;		// 0 == dojel si kolo, ale pokracuj dal
		}
		else {
			remove_solve_input(board, tried);
			return -1; // nasel vice reseni, ukonci to
		}
		
	}
	
	else if (col == 9) return solve_sudoku_stop_2(board, tried, row + 1, 0, solutions, frow, fcol);
	else if (board[row][col] != 0) return solve_sudoku_stop_2(board, tried, row, col + 1, solutions, frow, fcol);
	else {

		for (int number = 1; number < 10; number++) {

			if (is_valid(number, row, col, board)) {
				board[row][col] = number;
				tried[row][col] = 1;
				//show_bt(board);

				int result = solve_sudoku_stop_2(board, tried, row, col + 1, solutions, frow, fcol);
				
				switch (result) {
				case 1:
					printf("\n\n\n\n\n\nWTF tady fakt nemas co delat kamo, nekde musi byt velka chyba!!!!\n\n\n\n\n"); 
					Sleep(4000);
					return 1;
				case 0:
					board[row][col] = 0;
					tried[row][col] = 0;
					break;
				case - 1:
					return -1;
				}

			}
		}

		if (row == frow && col == fcol && *solutions == 1) return 1;	// je uplne nakonci a nasel jen jedno reseni
		return 0;	// nenasel nic
	}
}

void show_bt(int board[9][9]) {

	system("cls");
	printf("------------------------------\n");
	for (int row = 0; row < 9; row++) {
		for (int column = 0; column < 9; column++) {
			
			if (board[row][column] == 0) {
				printf("|  ");
			}
			else {
				printf("|%d ", board[row][column]);
			}
			if ((column + 1) % 3 == 0) printf("|");
		}
		if ((row + 1) % 3 == 0 && row != 8) printf("\n|============================|");
		else if (row == 8) printf("\n------------------------------");
		printf("\n");
	}
	Sleep(100);
}


int  print_board(int board[9][9], int sudoku[9][9], int guess[9][9], int number_stats[9], int max_mistakes) {

	int score = 0, mistake = 0;
	int cmd = 0;
	int select_row = 0, select_column = 0;

	while (!sudoku_is_completed(board)) {
		while (cmd != KB_ENTER || board[select_row][select_column] != 0) {	//nemuze vybrat cislo, ktere bylo zadane pocitacem

			system("cls");
			printf("------------------------------\n");
			for (int row = 0; row < 9; row++) {
				for (int column = 0; column < 9; column++) {

					if (guess[row][column] == 0) {
						if (board[row][column] == 0) {

							if (row == select_row && column == select_column) {
								printf("|" COLOR_BOLD "  " COLOR_OFF);
							}
							else if (row == select_row || column == select_column) {
								printf("|" COLOR_CROSS "  " COLOR_OFF);
							}
							else {
								printf("|  ");
							}
						}
						else {

							if (row == select_row && column == select_column) {
								printf("|" COLOR_BOLD "%d " COLOR_OFF, board[row][column]);
							}
							else if (row == select_row || column == select_column) {
								printf("|" COLOR_CROSS "%d " COLOR_OFF, board[row][column]);
							}
							else {
								printf("|%d ", board[row][column]);
							}
						}
					}

					else if (guess[row][column] > 0) {
						if (board[row][column] == 0) {

							if (row == select_row && column == select_column) {
								printf("|" COLOR_GUESS_SELECTED "%d " COLOR_OFF, guess[row][column]);
							}
							else if (row == select_row || column == select_column) {
								printf("|" COLOR_CROSS_GUESS "%d " COLOR_OFF, guess[row][column]);
							}
							else {
								printf("|" COLOR_GUESS "%d " COLOR_OFF, guess[row][column]);
							}
						}
					}
					else {
						int positive_number = ((guess[row][column]) * (-1));
						if (board[row][column] == 0) {

							if (row == select_row && column == select_column) {
								printf("|" COLOR_WRONG_SELECTED "%d " COLOR_OFF, positive_number);
							}
							else if (row == select_row || column == select_column) {
								printf("|" COLOR_CROSS_WRONG "%d " COLOR_OFF, positive_number);
							}
							else {
								printf("|" COLOR_WRONG "%d " COLOR_OFF, positive_number);
							}
						}

					}

					if ((column + 1) % 3 == 0) printf("|");
				}
				if ((row + 1) % 3 == 0 && row != 8) printf("\n|============================|");
				else if (row == 8) printf("\n------------------------------");
				printf("\n");
			}

			printf("Zbyva: %dx1	%dx2	%dx3	%dx4	%dx5	%dx6	%dx7	%dx8	%dx9\n",
				9 - number_stats[0], 9 - number_stats[1], 9 - number_stats[2], 9 - number_stats[3], 9 - number_stats[4],
				9 - number_stats[5], 9 - number_stats[6], 9 - number_stats[7], 9 - number_stats[8]);

			printf("\n\nPocet chyb: %d/%d\n", mistake, max_mistakes);
			printf("\nPro ukonceni hry stisknete ESC...\n");

			cmd = _getch();

			switch (cmd) {
			case KB_ESC:
				return - 1;
			case ARROW_UP:
				if (select_row > 0) {
					select_row--;
				}
				break;
			case ARROW_LEFT:
				if (select_column > 0) {
					select_column--;
				}
				break;
			case ARROW_RIGHT:
				if (select_column < 8) {
					select_column++;
				}
				break;
			case ARROW_DOWN:
				if (select_row < 8) {
					select_row++;
				}
				break;
			}
		}


		int point = 0;
		int kb_input = 0;

		while (kb_input != KB_ENTER) {

			char ptr[4]{ 0 };
			ptr[point] = 'o';

			system("cls");

			printf("Vyberte jednu z moznosti: \n\n");


			printf(" Zadat finalni cislo	%c\n", ptr[0]);
			printf(" Zadat pomocne cislo	%c\n", ptr[1]);
			printf(" Vymazat pomocne cislo	%c\n", ptr[2]);
			printf(" Zpet			%c\n", ptr[3]);

			kb_input = _getch();

			switch (kb_input) {
			case ARROW_UP:
				if (point > 0) {
					point--;
				}
				break;
			case ARROW_DOWN:
				if (point < 3) {
					point++;
				}
				break;
			}
		}

		int user_input;

		switch (point) {
		case 0:								//final number

			system("cls");

			printf("Zadej cislo od 1 do 9: ");
			scanf_s("%d", &user_input);

			if (sudoku[select_row][select_column] == user_input) {
				printf("\nspravne!\n");
				Beep(440, 300);
				Sleep(500);
				board[select_row][select_column] = user_input;
				number_stats[user_input - 1]++;		//number_stats drzi informaci kolik cisel je spravne na poli
				auto_delete_guess_numbers(user_input, select_row, select_column, number_stats, board, guess);
				score++;
			}
			else {
				printf("chyba!!\n");
				Beep(220, 300);
				Sleep(500);
				mistake++;
				score--;
				guess[select_row][select_column] = -user_input;
				if (max_mistakes == mistake) return -1;
			}
			cmd = 0;
			break;
		case 1:								//guess number
			system("cls");

			printf("Zadej pomocne cislo od 1 do 9: ");
			scanf_s("%d", &user_input);
			if (is_valid(user_input, select_row, select_column, board)) {
				guess[select_row][select_column] = user_input;
			}
			else {
				printf("Na tomto miste %d urcite byt nemuze ...\n", user_input);
				Sleep(1000);
			}
			cmd = 0;

			break;
		case 2:								//erase
			if (guess[select_row][select_column] == 0) {
				printf("Na vybranem poli neni zadne cislo, ktere by slo smazat...");
				Sleep(1000);
				break;
			}
			guess[select_row][select_column] = 0;
			cmd = 0;
			break;
		case 3:								//go back
			cmd = 0;
			break;
		}

	}

	return score;
}

void loose_melody() {
	Beep(554.4, 300);
	Beep(523.3, 300);
	Beep(493.9, 300);
	Beep(466.2, 600);
}

